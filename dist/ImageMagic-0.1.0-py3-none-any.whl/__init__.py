"""
# Copyright 2023 ASXE. All rights reserved.
Use ImageMagic.__version for this ImageMagic version
"""

from __future__ import annotations
import _version


__version__ = _version.__version__
__releasedate__ = _version.__releasedate__

