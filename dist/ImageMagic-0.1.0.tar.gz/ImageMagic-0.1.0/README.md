<div align="center">
  <img src="https://i.328888.xyz/2023/05/04/iPlOg8.png" width="500" height="450"><br>
</div>

# ImageMagic:一个简洁的图像（包括但不限于）处理库
[![Pypi](https://img.shields.io/badge/pypi-0.1.0-blue)]()
[![License](https://img.shields.io/badge/license-MIT-yellow)]()
[![]()]()

# 这是什么？
ImageMagic是Python的一个包，提供简洁的图像（包括但不限于）处理功能，主要体现为简洁二字。

# 获取

# 依赖
  - [PIL](https://github.com/python-pillow/Pillow)
  - [Tesseract-OCR](https://tesseract-ocr.github.io/tessdoc/Installation.html)


# 许可证
GNU GPL

# 为ImageMagic做贡献
欢迎所有贡献、错误报告、错误修复以及功能增强和想法。
